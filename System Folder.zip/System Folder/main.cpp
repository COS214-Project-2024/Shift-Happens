#include <memory>
#include <string>
#include <iostream>
#include <cstdlib>
// Game
#include "Game.h"

// BuildingFactories
#include "ResidentialBuildingFactory.h"
#include "CommercialBuildingFactory.h"
#include "IndustrialBuildingFactory.h"
#include "UtilityBuildingFactory.h"
#include "LandmarkBuildingFactory.h"
#include "InfrastructureFactory.h"
#include "TransportBuildingFactory.h" // Include TransportBuildingFactory

#include "BuildingFactory.h"

// Buildings
#include "Building.h"

// Residential buildings
#include "House.h"
#include "TownHouse.h"
#include "Estate.h"
#include "Apartment.h"

// Commercial buildings
#include "Store.h"
#include "Office.h"
#include "Mall.h"

// Industrial buildings
#include "Factory.h"
#include "Warehouse.h"
#include "Manufacturer.h"

// Utility buildings
#include "PowerPlant.h"
#include "WaterSupply.h"
#include "SewagePlant.h"
#include "LandFill.h"

// Landmarks
#include "Monument.h"
#include "Park.h"
#include "CulturalCenter.h"

// Infrastructure
#include "Road.h"
#include "Railway.h"

// Transport buildings
#include "Airport.h"
#include "BusStation.h"
#include "TrainStation.h"


using namespace std;

void demo() {
   
    try{
        Game game;
        game.run();
    } catch (char const* msg) {
        cout << msg << endl;
    }
}

void testBuildingFactory() {
    cout << "Testing Building Factory" << endl;
    cout << "Creating Building Factories of each type" << endl;
    shared_ptr<BuildingFactory> resFactory = make_shared<ResidentialBuildingFactory>(1);
    shared_ptr<BuildingFactory> comFactory = make_shared<CommercialBuildingFactory>(2);
    shared_ptr<BuildingFactory> indFactory = make_shared<IndustrialBuildingFactory>(3);
    shared_ptr<BuildingFactory> utiFactory = make_shared<UtilityBuildingFactory>(4);
    shared_ptr<BuildingFactory> landFactory = make_shared<LandmarkBuildingFactory>(5);
    shared_ptr<BuildingFactory> infraFactory = make_shared<InfrastructureFactory>(6);
    shared_ptr<BuildingFactory> transFactory = make_shared<TransportBuildingFactory>(7); // Create TransportBuildingFactory

    cout << "Creating Buildings" << endl;
    resFactory->createBuilding("House");
    resFactory->createBuilding("TownHouse");
    resFactory->createBuilding("Estate");
    resFactory->createBuilding("Apartment");

    comFactory->createBuilding("Store");
    comFactory->createBuilding("Office");
    comFactory->createBuilding("Mall");

    indFactory->createBuilding("Factory");
    indFactory->createBuilding("Warehouse");
    indFactory->createBuilding("Manufacturer");

    utiFactory->createBuilding("PowerPlant");
    utiFactory->createBuilding("WaterSupply");
    utiFactory->createBuilding("SewagePlant");
    utiFactory->createBuilding("LandFill");

    landFactory->createBuilding("Park");
    landFactory->createBuilding("Monument");
    landFactory->createBuilding("CulturalCenter");

    infraFactory->createBuilding("Road");
    infraFactory->createBuilding("Railway");

    transFactory->createBuilding("Airport"); // Create transport buildings
    transFactory->createBuilding("BusStation");
    transFactory->createBuilding("TrainStation");

    // Print buildings
    cout << "Printing Buildings" << endl;
    resFactory->print();
    comFactory->print();
    indFactory->print();
    utiFactory->print();
    landFactory->print();
    infraFactory->print();
    transFactory->print(); // Print transport buildings
}

void testMap() {
    cout << "Testing Map" << endl;

    // Get the singleton instance of the Map
    Map& map = Map::getInstance();

    // Build some buildings on the map
    map.build("House", "Residential", 0, 0);
    map.build("Store", "Commercial", 1, 1);
    map.build("Factory", "Industrial", 2, 2);
    map.build("PowerPlant", "Utility", 3, 3);
    map.build("Park", "Landmark", 4, 4);
    map.build("Road", "Infrastructure", 5, 5);
    map.build("Airport", "Transport", 6, 6);

    // Print the map
    map.print();
}

int main() {
    demo();
    //testBuildingFactory();
    //testMap();
    return 0;
}