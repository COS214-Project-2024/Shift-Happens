#include "Policy.h"

double Policy::getCostOfPolicy(){
  return this->Cost;
}