#include "BuildingFactory.h"

BuildingFactory::BuildingFactory(int id)
{
    this->id = id;
    buildingId = 0;
}
BuildingFactory::~BuildingFactory()
{
    
}