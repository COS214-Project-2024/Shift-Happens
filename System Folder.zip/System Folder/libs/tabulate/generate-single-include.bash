#!/usr/bin/env bash
python3 utils/amalgamate/amalgamate.py -c single_include.json -s .
